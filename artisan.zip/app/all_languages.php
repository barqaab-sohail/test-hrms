<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class all_languages extends Model
{
    //
}
