<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Employee Name: <?php echo e($employee->first_name. " ".$employee->last_name); ?></h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   
    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-2">
					<?php echo $__env->make('layouts.master.hrVerticalEditButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
        			
		        	<div class="col-lg-10">

		                <div style="margin-top:10px; margin-right: 10px;">
		                    <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-info float-right">Back</button>
		                    
		                </div>
		                <div class="card-body">

		                    <form action="<?php echo e(route('storePosting')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Posting</h3>
		                            <hr class="m-t-0 m-b-40">
		                            <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Position</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="position" value="<?php echo e(old('position')); ?>" class="form-control" placeholder="Enter Position Name" required >
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-5">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-4">Posting Date</label>
		                                        <div class="col-md-8">
		                                            <input type="text" id="posting_date" name="posting_date" value="<?php echo e(old('posting_date')); ?>" class="form-control " placeholder="Enter Posting Date" required readonly>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                            <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Manager Name</label>
		                                        <div class="col-md-9">
		                                           <select  name="manager_id"  class="form-control" required>
                                                        <option value=""></option>
                                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($employee->id); ?>" <?php echo e((old("manager_id")==$employee->id? "selected" : "")); ?>><?php echo e($employee->first_name." ".$employee->last_name.", ".$employee->designation); ?></option>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      
                                                    </select>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-5">
		                                    <div class="form-group row">
		                                       
		                                    </div>
		                                </div>
		                            </div>
		                                
		                            <!--/row-->
		                             <div class="row">
		                                <div class="col-md-7">
                                	
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Project</label>
		                                        <div class="col-md-9">
			
		                                            <select  name="project"  class="form-control" required>
                                                        <option value=""></option>
                                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($project->name); ?>" <?php echo e((old("project")==$project->name? "selected" : "")); ?>><?php echo e($project->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      
                                                    </select>

		                                        </div>
		                                      
		                                   
		                                    </div>
		                                </div>
		                                <div class="col-md-5">
                                	
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-4">Location</label>
		                                        <div class="col-md-8">
		                                        	<input type="text" name="location" value="<?php echo e(old('location')); ?>" class="form-control " placeholder="Enter Location" >
		                                        </div>
		                                       
		                                       <input type="number" name="employee_id" value="<?php echo e(session('employee_id')); ?>"   class="form-control " hidden>
		                                   
		                                    </div>
		                                </div>

		                                		                                
		                            </div>
		                            		                           
		                        </div>
		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Add Posting</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>
		<?php if($postingIds->count()!=0): ?>		                    
			                    <br>
			                    <hr>
			                    <br>
		<div class="card">
		<div class="card-body">
			<!--<div class="float-right">
				<input id="month" class="form-control" value="" type="month">
			</div>-->
			<h2 class="card-title">Stored Posting</h2>
			
			<div class="table-responsive m-t-40">
				
				<table id="myTable" class="table table-bordered table-striped" width="100%" cellspacing="0">
					<thead>
					
					<tr>
						<th>Project</th>
						<th>Position</th>
						<th>Date of Posting</th>
						
						<?php if(Auth::user()->role_id==1): ?><th> Actions </th> <?php endif; ?>
					</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $postingIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postingId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($postingId->project); ?></td>
								<td><?php echo e($postingId->position); ?></td>
								<td><?php echo e($postingId->posting_date); ?></td>
								
								<td>
								<?php if(Auth::user()->role_id==1): ?>
								 <a class="btn btn-info btn-sm" href="<?php echo e(route('posting.edit',['id'=>$postingId->id])); ?>" data-toggle="tooltip" data-original-title="Edit"> <i class="fas fa-pencil-alt text-white "></i></a>
								  <a class="btn btn-danger btn-sm" onclick="return confirm('Are you Sure to Delete')" href="<?php echo e(route('deletePosting',['id'=>$postingId->id])); ?>" data-toggle="tooltip" data-original-title="Delete"> <i class="fas fa-trash-alt"></i></a>
								 <?php endif; ?>
															
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					 
					
					</tbody>
				</table>
			</div>
		</div>
	</div>
	
	<?php endif; ?>
			                    
		        		</div>       
		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function(){
            	$( "#posting_date" ).datepicker({
	     		dateFormat: 'dd-MM-yy',
	      		yearRange: (new Date().getFullYear()-20)+':'+(new Date().getFullYear()+15),
	      		changeMonth: true,
	      		changeYear: true
	    		});
	    		
			
			});
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/hr/posting/posting.blade.php ENDPATH**/ ?>