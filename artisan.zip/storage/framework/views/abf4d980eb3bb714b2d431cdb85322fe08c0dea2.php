<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Employee Name: <?php echo e($employee->first_name. " ".$employee->last_name); ?></h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-2">
					<?php echo $__env->make('layouts.master.hrVerticalEditButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
        	
		        	<div class="col-lg-10">

		                <div style="margin-top:10px; margin-right: 10px;">
		                    <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-info float-right">Back</button>
		                </div>
		                <div class="card-body">

		                    <form action="<?php echo e(route('editPicture', ['id'=>session('employee_id')])); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        
		                        <div class="form-body">
		                            <center >
		                            
		                                <input type="image"  src="<?php echo e(asset(isset($picture->name)? 'upload/pictures/'.$picture->name: 'Massets/images/default.png')); ?>" class="img-circle picture-container picture-src"  id="wizardPicturePreview" title="" width="150" />
		                                <input type="file"  name="picture" id="wizard-picture" class="" required hidden>

		                                <h6 class="card-title m-t-10">Click On Image to Add Picture</h6>

		                                
		                            </center>
		                        </div>
		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Update Picture</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>
		        		</div>       
		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>
        <script>

            $(document).ready(function(){
// Prepare the preview for profile picture
		        $("#wizard-picture").change(function(){
		        	
		        	var fileSize = this.files[0].size;
		        	if (fileSize>50000)
		        	{
		        		alert('File Size is very large '+fileSize);
		        		$(this).val('');
		        	}else{
	    				switch(val.substring(val.lastIndexOf('.') + 1).toLowerCase()){
	        			case 'jpg': case 'png':
	        			break;
	        			default:
	            		$(this).val('');
	            		// error message here
	            		alert("only allow JPG and PNG Files");
	            		break;
	    				}
	    			readURL(this);
	    			}
                });
            });
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function (e) {
                        $('#wizardPicturePreview').attr('src', e.target.result).fadeIn('slow');
                    }
                    reader.readAsDataURL(input.files[0]);
                }           }
            $("input[type='image']").click (function() {
                $("input[id='wizard-picture']").click();
            });

           
           /*$(".form-control").keypress(function(e) {
           	
                if (e.which == 13) {
                    e.preventDefault();
                    return false;
                }
            });

            $('#asana_teams input[type="checkbox"]').each(function () {
                var $checkbox = $(this);
                $checkbox.checkbox();
            });*/
        </script>

        

    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/employee/editPicture.blade.php ENDPATH**/ ?>