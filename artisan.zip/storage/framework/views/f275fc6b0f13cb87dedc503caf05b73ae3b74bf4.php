<div class="btn-group-vertical" role="group" aria-label="vertical button group">

         
          <br>
          
           <?php if(request()->is('createEmployee')): ?>
             <a type="submit" role="button" href="<?php echo e(route('createEmployee')); ?>" class="btn btn-info <?php if(request()->is('createUser')): ?> active <?php endif; ?>" >Personal Information</a>

            <?php else: ?>

            <a type="submit" role="button" href="<?php echo e(route('employee.edit',session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*employee/edit*')): ?> active <?php endif; ?>" >Personal Information</a>
            <a type="submit" role="button"  href="<?php echo e(route('user.edit', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*user/edit*')): ?> active <?php endif; ?>">User</a>
            <a type="submit" role="button"  href="<?php echo e(route('picture.edit', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*icture*')): ?> active <?php endif; ?>">Picture</a>
            <a type="submit" role="button"  href="<?php echo e(route('appointment.edit', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*appointment/edit*')): ?> active <?php endif; ?>">Appointment  Detail</a>
            <a type="submit" role="button"  href="<?php echo e(route('posting', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*posting*')): ?> active <?php endif; ?>">Posting</a>
            <a type="submit" role="button"  href="<?php echo e(route('education', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*education*')): ?> active <?php endif; ?>">Education</a>
            <a type="submit" role="button"  href="<?php echo e(route('training', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*training*')): ?> active <?php endif; ?>">Training</a>
            <a type="submit" role="button"  href="<?php echo e(route('publication', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*publication*')): ?> active <?php endif; ?>">Publication</a>
            <a type="submit" role="button"  href="<?php echo e(route('membership', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*membership*')): ?> active <?php endif; ?>">Membership</a>
            <a type="submit" role="button"  href="<?php echo e(route('language', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*language*')): ?> active <?php endif; ?>">Language</a>
            <a type="submit" role="button"  href="<?php echo e(route('experience', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*experience*')): ?> active <?php endif; ?>">Experience</a>
            <a type="submit" role="button"  href="<?php echo e(route('promotion', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*promotion*')): ?> active <?php endif; ?>">Promotion</a>
            <a type="submit" role="button"  href="<?php echo e(route('bank', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*bank*')): ?> active <?php endif; ?>">Bank</a>
            <a type="submit" role="button" href="<?php echo e(route('contact.edit', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*contact/edit*')): ?> active <?php endif; ?>">Contact Detail</a>
            <a type="submit" role="button"  href="<?php echo e(route('emergency', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*emergency*')): ?> active <?php endif; ?>">Emergency Contact</a>
            <a type="submit" role="button"  href="<?php echo e(route('dependent', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*dependent*')): ?> active <?php endif; ?>">Dependent</a>
            <a type="submit" role="button"  href="<?php echo e(route('document', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*document*')): ?> active <?php endif; ?>">Document</a>
            <a type="submit" role="button"  href="<?php echo e(route('other.edit', session('employee_id'))); ?>" class="btn btn-info <?php if(request()->is('*other/edit*')): ?> active <?php endif; ?>">Other Information</a>

           <a type="submit" role="button"   href="#" class="btn btn-info">Exit Interview</a>


             <?php endif; ?>
             
</div><?php /**PATH C:\xampp\htdocs\hrms\resources\views/layouts/master/hrVerticalEditButton.blade.php ENDPATH**/ ?>