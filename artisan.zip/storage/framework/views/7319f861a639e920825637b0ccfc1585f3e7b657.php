<?php $__env->startSection('content'); ?>

	
	<div class="col-md-10 col-md-offset-1">
    	<h3 class="well well-sm" >List of Employees</h3>   		
    				
				<div class="row">
		        		             
			    	<div class="container-fluid">
		                <table  id="myTable" class="display nowrap table table-hover table-striped table-bordered" style="width:100%">
		                  <thead>
		                  <tr>
		                    <th style="width:15%">First Name</th>
		                    <th style="width:15%">Middle Name</th>
		                    <th style="width:15%">Last Name</th>
		                    <th style="width:10%">CNIC</th>
		                    <th style="width:10%">From</th>
		                    <th style="width:10%">To</th>
		                    <th style="width:5%">Duration</th>
		                   </tr>
		                  </thead>
		                  <tbody>
						
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					   		<tr>
			                    <td><?php echo e($user->first_name); ?></td>
			                    <td><?php echo e($user->middle_name); ?></td>
			                    <td><?php echo e($user->last_name); ?></td>
			                    <td><?php echo e($user->cnic); ?></td>
			                    <td> <img src="<?php echo e(url('upload/'.$user->picture)); ?>"></td>
			                    <td><img src="<?php echo e(storage_path('app/public/'.$user->picture)); ?>"></td>
	                		</tr>
           				 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
		            	</table>
		            	<?php echo e($users->links()); ?>

		            	
					
					</div>
				</div>
	</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/listOfEmployees.blade.php ENDPATH**/ ?>