 <?php $__env->startPush('scripts'); ?>
      
    <?php $__env->stopPush(); ?>


<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Dashboard</h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
		 <h2 class="box-title">Departmentwise Charts</h2>
			<div id="app">
            <?php echo $chart->container(); ?>

        </div>
        <script src="https://unpkg.com/vue"></script>
        <script>
            var app = new Vue({
                el: '#app',
            });
        </script>
         <?php echo $chart->script(); ?>

			<!--<div class="float-right">
				<input id="month" class="form-control" value="" type="month">
			</div>
			<h4 class="card-title">Salaries</h4>
		
			
			<h1 class="card-subtitle"><?php echo e(Auth::User()->employee->first_name." ".Auth::User()->employee->last_name); ?> Welcome to HRMS</h1>
						-->
			
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/chart.blade.php ENDPATH**/ ?>