<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Employee Name: <?php echo e($employee->first_name. " ".$employee->last_name); ?></h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   
    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-2">
					<?php echo $__env->make('layouts.master.hrVerticalEditButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
        			
		        	<div class="col-lg-10">

		                <div style="margin-top:10px; margin-right: 10px;">
		                    <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-info float-right">Back</button>
		                    
		                </div>
		                <div class="card-body">

		                    <form action="<?php echo route('editPublication', ['id'=>optional($data)->id]); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Publication</h3>
		                            <hr class="m-t-0 m-b-40">
									<div class="row">
		                                <div class="col-md-12">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-2">Title</label>
		                                        <div class="col-md-10">
		                                        	<input type="text"  name="title" value="<?php echo old('title', optional($data)->title); ?>" placeholder="Enter Publication Title " class="form-control"  required>
		                                            
		                                        </div>
		                                    </div>
		                                </div>
		                               
		                               
		                            </div>
		                                
		                            <!--/row-->

		                            <div class="row">
		                                <div class="col-md-12">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-2">Description</label>
		                                        <div class="col-md-10">
		                                            <textarea type="text" rows=3 cols=20 name="description" class="form-control" placeholder="Enter Description"><?php echo old('description', optional($data)->description); ?></textarea>
		                                        </div>
		                                    </div>
		                                </div>
		                               
		                               
		                            </div>
		                                
		                            <!--/row-->
		                             <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-4">Channel/Media</label>
		                                        <div class="col-md-8">
		                                            <input type="text"  name="channel" value="<?php echo old('channel', optional($data)->channel); ?>" placeholder="Enter Publication Channel/Media " class="form-control"  required>
		                                        </div>
		                                        
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-4">Year</label>
		                                        <div class="col-md-8">
		                                            <input type="text"  name="year" value="<?php echo old('year', optional($data)->year); ?>" class="form-control"  placeholder="Enter Year of Publication" >
		                                        </div>

		                                        <input type="number" name="employee_id" value="<?php echo e(session('employee_id')); ?>"   class="form-control " hidden>
		                                    </div>
		                                </div>
		                            </div>
		                            		                           
		                        </div>
		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Add Publication</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>
		<?php if($publicationIds->count()!=0): ?>		                    
			                    <br>
			                    <hr>
			                    <br>
		<div class="card">
		<div class="card-body">
			<!--<div class="float-right">
				<input id="month" class="form-control" value="" type="month">
			</div>-->
			<h2 class="card-title">Stored Publication</h2>
			
			<div class="table-responsive m-t-40">
				
				<table id="myTable" class="table table-bordered table-striped" width="100%" cellspacing="0">
					<thead>
					
					<tr>
						<th>Description</th>
						<th>Channel</th>
						<th>Year</th>
						
						<?php if(Auth::user()->role_id==1): ?><th> Actions </th> <?php endif; ?>
					</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $publicationIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicationId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($publicationId->description); ?></td>
								<td><?php echo e($publicationId->channel); ?></td>
								<td><?php echo e($publicationId->year); ?></td>
								
								<td>
								<?php if(Auth::user()->role_id==1): ?>
								 <a class="btn btn-info btn-sm" href="<?php echo e(route('publication.edit',['id'=>$publicationId->id])); ?>" data-toggle="tooltip" data-original-title="Edit"> <i class="fas fa-pencil-alt text-white "></i></a>
								 <a class="btn btn-danger btn-sm" onclick="return confirm('Are you Sure to Delete')" href="<?php echo e(route('deletePublication',['id'=>$publicationId->id])); ?>" data-toggle="tooltip" data-original-title="Delete"> <i class="fas fa-trash-alt"></i></a>
								 <?php endif; ?>
															
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					 
					
					</tbody>
				</table>
			</div>
		</div>
	</div>
	
	<?php endif; ?>
			                    
		        		</div>       
		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function(){
			
			});
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/hr/publication/editPublication.blade.php ENDPATH**/ ?>