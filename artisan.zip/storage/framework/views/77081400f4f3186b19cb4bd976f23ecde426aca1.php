<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Human Resource</h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)">New Employee</a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-2">
					<?php echo $__env->make('layouts.master.hrVerticalButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
        	
		        	<div class="col-lg-10">

		                <div style="margin-top:10px; margin-right: 10px;">
		                    <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-info float-right">Back</button>
		                </div>
		                <div class="card-body">

		                    <form action="<?php echo e(route('storeEmployee')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Employee Information</h3>
		                            <hr class="m-t-0 m-b-40">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">First Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="first_name" value="<?php echo e(old('first_name')); ?>"  class="form-control" placeholder="Enter First Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Middle Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="middle_name" value="<?php echo e(old('middle_name')); ?>" class="form-control " placeholder="Enter Middle Name" >
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Last Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>"   class="form-control " placeholder="Enter Last Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Father Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="father_name" value="<?php echo e(old('father_name')); ?>" class="form-control " placeholder="Enter Father Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>
		                            <!--/row-->
		                            <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Date of Birth</label>
		                                        <div class="col-md-9">
		                                            <input type="text" id="date_of_birth" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>" class="form-control " placeholder="Enter Date of Birth" required readonly>
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Gender</label>
		                                        <div class="col-md-9">
		                                            <div class="col-md-9">
		                                           	 <select  name="gender"  class="form-control" required>
                                                        <option value=""></option>
                                                        <option value="Male"  <?php echo e(old('gender') == "Male" ? 'selected' : ''); ?>>Male </option>
                                                        <option value="Female"  <?php echo e(old('gender') == "Female" ? 'selected' : ''); ?>>Female </option>
                                                        
                                                    </select>
		                                            
		                                        </div>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>
		                            <!--/row-->
		                            <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">CNIC</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="cnic" pattern="[0-9]{13}" title= "13 digit Number without dash" value="<?php echo e(old('cnic')); ?>" class="form-control " placeholder="Enter CNIC without dash" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">CNIC Expiry</label>
		                                        <div class="col-md-9">
		                                            <div class="col-md-9">
		                                            <input type="text" id="cnic_expiry" name="cnic_expiry" value="<?php echo e(old('cnic_expiry')); ?>" class="form-control "  placeholder="Enter CNIC Expiry Date" readonly required>
		                                        </div>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                
		                            </div>
		                            <!--/row-->

		                            
		                            <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Employee No.</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="employee_no" value="<?php echo e(old('employee_no')); ?>" class="form-control " placeholder="Enter Employee No" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Marital Status</label>
		                                        <div class="col-md-9">
		                                            <div class="col-md-9">
		                                           	 <select  name="marital_status"  class="form-control" required>
                                                        <option value=""></option>
                                                        <?php $__currentLoopData = $maritalStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maritalStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($maritalStatus->name); ?>" <?php echo e((old("marital_status")==$maritalStatus->name? "selected" : "")); ?>><?php echo e($maritalStatus->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      
                                                    </select>
		                                            
		                                        </div>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>
		                        <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Religon</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="religon" value="<?php echo e(old('religon')); ?>" class="form-control " placeholder="Enter Religon" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Nationality</label>
		                                        <div class="col-md-9">
		                                            <div class="col-md-9">
		                                            <select  name="nationality"  class="form-control" required>
		                                           	<option value=""></option>
		                                           	<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($country->name); ?>" <?php echo e((old("nationality")==$country->name? "selected" : "")); ?>><?php echo e($country->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 	
                                                    </select>

		                                        </div>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>
								     <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Department</label>
		                                        <div class="col-md-9">
		                                            <div class="col-md-9">
		                                           	 <select  name="department_id"  class="form-control" required>
                                                        <option value=""></option>
                                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($department->id); ?>" <?php echo e((old("department_id")==$department->id? "selected" : "")); ?>><?php echo e($department->name); ?></option>										
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                               
                                                    </select>
		                                            
		                                        </div>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>


		                        </div>
		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Add Employee</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>
		        		</div>       
		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>


<script>
    $( function() {
	    $( "#date_of_birth" ).datepicker({
	      dateFormat: 'dd-MM-yy',
	      yearRange: '1940:'+ (new Date().getFullYear()-15),
	      changeMonth: true,
	      changeYear: true
	    });
	    $( "#cnic_expiry" ).datepicker({
	      dateFormat: 'dd-MM-yy',
	      yearRange:  new Date().getFullYear()+':'+(new Date().getFullYear()+15),
	      changeMonth: true,
	      changeYear: true
	    });

	    $('select').select2({
  			maximumSelectionLength: 2,

		});
  	});
</script>

        

    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/employee/createEmployee.blade.php ENDPATH**/ ?>