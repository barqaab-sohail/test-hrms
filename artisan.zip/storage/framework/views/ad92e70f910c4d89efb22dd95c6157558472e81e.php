<?php $__env->startSection('content'); ?>


<div>
	
	<h1> Mr. <?php echo e(Auth::user()->first_name ." ".Auth::user()->last_name); ?> WELCOME TO HRMS</h1>

</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>