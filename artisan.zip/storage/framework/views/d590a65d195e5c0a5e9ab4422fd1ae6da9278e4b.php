<?php if(count($errors)>0): ?>
		<ul class="list-group">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert">&times;</a>
					<?php echo e($abc); ?>

				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</ul>
<?php endif; ?>
 <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <a href="#" class="close" data-dismiss="alert">&times;</a>
                    <strong></strong> <?php echo e(Session::get('success')); ?>

                </div>
<?php endif; ?>


 <?php if(Session::has('message')): ?>
        <div class="alert alert-success" align="left">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong></strong> <?php echo e(Session::get('message')); ?>

        </div>
 <?php endif; ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/layouts/master/errors.blade.php ENDPATH**/ ?>