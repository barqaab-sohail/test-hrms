<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor"></h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   

    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-1">
					</div>
		        	<div class="col-lg-10">
						
		                <div style="margin-top:10px; margin-right: 10px;">
		                    		                    
		                </div>
		                <div class="card-body">

		                    <form action="<?php echo e(route('storeDesignation')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Designations</h3>
		                            <hr class="m-t-0 m-b-40">
		                            <div class="row">
		                                <div class="col-md-9">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Designation Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="name" value="" class="form-control" placeholder="Enter Designation Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-3">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-6">Designation Level</label>
		                                        <div class="col-md-6">
		                                            <select  name="level"  class="form-control" >
                                                        <option value=""></option>
                                                        <?php for($i = 1; $i < 15; $i++): ?>
    													<option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
														<?php endfor; ?>
                                                    </select>
		                                        </div>
		                                    </div>
		                                   
		                                </div>
		                            </div>

		                        </div>
		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Save</button>
		                                           
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>

<?php if($designationIds->count()!=0): ?>		                    
			                    <br>
			                    <hr>
			                    <br>
		<div class="card">
		<div class="card-body">
			<!--<div class="float-right">
				<input id="month" class="form-control" value="" type="month">
			</div>-->
			<h2 class="card-title">Stored Designations</h2>
			
			<div class="table-responsive m-t-40">
				
				<table id="myTable" class="table table-bordered table-striped" width="100%" cellspacing="0">
					<thead>
					
					<tr>
						<th>Designation Name</th>
						<th>Level</th>
						<?php if(Auth::user()->role_id==1): ?><th> Actions </th> <?php endif; ?>
					</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $designationIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designationId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($designationId->name); ?></td>
								<td><?php echo e($designationId->level); ?></td>
								
								<td>
								<?php if(Auth::user()->role_id==1): ?>
								 <a class="btn btn-info btn-sm" href="<?php echo e(route('designation.edit',['id'=>$designationId->id])); ?>" data-toggle="tooltip" data-original-title="Edit"> <i class="fas fa-pencil-alt text-white "></i></a>
								  <a class="btn btn-danger btn-sm" onclick="return confirm('Are you Sure to Delete')" href="<?php echo e(route('deleteDesignation',['id'=>$designationId->id])); ?>" data-toggle="tooltip" data-original-title="Delete"> <i class="fas fa-trash-alt"></i></a>
								 <?php endif; ?>
															
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					 
					
					</tbody>
				</table>
			</div>
		</div>
	</div>
	
	<?php endif; ?>


		        		</div>       
		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>
        <script>
           $(document).ready(function() {
            $('#myTable').DataTable({
                stateSave: false,
                dom: 'Blfrtip',
                buttons: [
                    {
                        extend: 'copyHtml5',
                        exportOptions: {
                            columns: [ 0, 1]
                        }
                    },
                    {
                        extend: 'excelHtml5',
                        exportOptions: {
                            columns: [ 0, 1]
                        }
                    },
                    {
                        extend: 'pdfHtml5',
                        exportOptions: {
                            columns: [ 0, 1]
                        }
                    }, {
                        extend: 'csvHtml5',
                        exportOptions: {
                            columns: [ 0, 1]
                        }
                    },
                ]
            });
        });

        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/hr/designation/addDesignation.blade.php ENDPATH**/ ?>