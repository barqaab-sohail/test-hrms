<?php $__env->startSection('content'); ?>


	<div class="col-md-10 col-md-offset-1">
    	<h3 class="well well-sm" >New User</h3>   		
    	<form id="editEducation" method="post" action="<?php echo e(url('store')); ?>" enctype="multipart/form-data" >
    	<?php echo csrf_field(); ?>
    		<div class="well well-sm">
			    <div class="row">
			        <div class="col-sm-4 form-group">
			            <label >First Name</label> <span class="text-danger">*</span>
			            <input type="text" id="first_name" name="first_name" value="<?php echo e(old('first_name')); ?>" class="form-control"  required>
			        </div>
			        <div class="col-sm-4 form-group">
			            <label >Middle Name</label> <span class="text-danger"></span>
			            <input type="text" id="middle_name" name="middle_name" value="<?php echo e(old('middle_name')); ?>" class="form-control"  >
			        </div>
			        <div class="col-sm-4 form-group">
			            <label >Last Name</label> <span class="text-danger">*</span>
			            <input type="text" id="last_name" name="last_name"  class="form-control"  value="<?php echo e(old('last_name')); ?>" required>
			        </div>
			    </div>  
			  	<br>
			    <div class="row">
			       	<div class="col-sm-4 form-group">
			            <label >CNIC</label> <span class="text-danger"> *</span>
			            <input type="text" id="cnic" name="cnic"  value="<?php echo e(old('cnic')); ?>" class="form-control" required>
			        </div>
			        <div class="col-sm-3 form-group">
			            <label>CNIC Expiry</label> <span class="text-danger"> *</span>
			            <input type="date" id="cnic_expiry"  name="cnic_expiry" class="form-control" value="<?php echo e(old('cnic_expiry')); ?>" required>
			        </div>  
			        <div class="col-sm-5 form-group">
			            <label>Email</label> <span class="text-danger"> *</span>
			            <input type="email" id="email"  name="email" value="<?php echo e(old('email')); ?>" class="form-control" required>
			        </div>  
			        
			    </div>  
			    <div class="row">
			       	<div class="col-sm-4 form-group">
			            <label >Picture</label> <span class="text-danger"></span>
			            <input type="file" id="picture" name="picture"  value="<?php echo e(old('picture')); ?>" class="form-control" required>
			        </div>
			    </div>  
			    <br>
			    <br>
	 			<div class="row">
					<div class="col-sm-2 form-group">
						<button type="submit" id="submit" name="save" class="btn btn-lg btn-info">Save</button>
					</div>
					
					<div class="col-sm-4 form-group error">
						<?php if($errors->any()): ?>
	                        <div class="alert alert-danger">
		                        <button type="button" class="close" data-dismiss="alert">X</button>	
		                         <ul>
		                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                                <li><?php echo e($error); ?></li>
		                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                      	</ul>
	                      	</div>
                    	<?php endif; ?>
					</div>

					<div class="col-sm-4 form-group message">
					  		<?php if(session()->has('message')): ?>
					  		<div class="alert alert-success">
							<button type="button" class="close" data-dismiss="alert">X</button>	
	    					<?php echo e(session()->get('message')); ?>

	  						<?php endif; ?>
							</div>
					</div>
					
					<div class="col-sm-3 form-group">
					</div>



			    </div>
			</div>
    	</form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>