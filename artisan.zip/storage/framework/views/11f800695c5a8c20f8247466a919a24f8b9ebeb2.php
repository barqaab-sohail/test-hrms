<br>
<div class="row">
  <div class="col-12">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link <?php if(request()->is('employee/edit*')): ?> active <?php endif; ?>"  data-toggle="pill" href="#" role="tab" aria-controls="v-pills-home" aria-selected="true">Personal Information</a>
      <a class="nav-link"  data-toggle="pill" href="#" role="tab" aria-controls="v-pills-profile" aria-selected="false">Education</a>
      <a class="nav-link"  data-toggle="pill" href="#" role="tab" aria-controls="v-pills-messages" aria-selected="false">Salary</a>
      <a class="nav-link"  data-toggle="pill" href="#" role="tab" aria-controls="v-pills-settings" aria-selected="false">Contact Detail</a>
    </div>
  </div>
  
</div><?php /**PATH C:\xampp\htdocs\hrms\resources\views/layouts/master/hrVerticalTab.blade.php ENDPATH**/ ?>