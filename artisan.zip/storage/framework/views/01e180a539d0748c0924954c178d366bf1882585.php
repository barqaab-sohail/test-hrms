<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor"></h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   
    <div class="row">
        <div class="col-lg-12">
						
            <div class="card card-outline-info">
		                <div class="card-body">
							<div style="margin-top:10px; margin-right: 10px;">
			                    <button type="button" onclick="window.location.href='<?php echo e(route('notificationList')); ?>'" class="btn btn-info float-right">List</button>
			                </div>
                   
		                       
		                        <div class="form-body">
		                        <h3 class="box-title">Notification</h3>
		                            <hr class="m-t-0 m-b-40">
		                            
		                                <div class="form-group row">
		                                    <label class="control-label text-right col-md-2">Created Date:</label>
		                                    <div class="col-md-9">
		                                        <?php echo e(date('d-M-Y',strtotime($notification->created_at))); ?>

		                                    </div>
		                                </div>

		                                <div class="form-group row">
		                                    <label class="control-label text-right col-md-2">Subject:</label>
		                                    <div class="col-md-9" >
		                                        <?php echo e($notification->data['letter']['subject']); ?>

		                                    </div>
		                                </div>
		                        
									
		                                <div class="form-group row">
		                                    <label class="control-label text-right col-md-2">Message:</label>
		                                    <div class="col-md-9" style="text-align: justify">
		                                        <?php echo e($notification->data['letter']['message']); ?>

		                                    </div>
		                                </div>
		                            
		                        </div>
		                         <hr>
		                </div>       
		        	
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function(){

            });
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/hr/notification/showNotification.blade.php ENDPATH**/ ?>