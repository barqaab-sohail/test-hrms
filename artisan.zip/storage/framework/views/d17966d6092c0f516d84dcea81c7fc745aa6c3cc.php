<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Employee Name: <?php echo e($employee->first_name. " ".$employee->last_name); ?></h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   
    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-2">
					<?php echo $__env->make('layouts.master.hrVerticalEditButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
        			
		        	<div class="col-lg-10">

		                <div style="margin-top:10px; margin-right: 10px;">
		                    <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-info float-right">Back</button>
		                    
		                </div>
		                <div class="card-body">

		                    <form action="<?php echo e(route('storeExperience')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Experience</h3>
		                            <hr class="m-t-0 m-b-40">
		                            <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Employer</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="employer" value="<?php echo e(old('employer')); ?>" class="form-control" placeholder="Enter Employer Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-5">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Position</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="position" value="<?php echo e(old('position')); ?>" class="form-control " placeholder="Enter Position Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                                
		                            <!--/row-->
		                             <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">From</label>
		                                        <div class="col-md-4">
		                                            <input type="text" id="from" name="from" value="<?php echo e(old('from')); ?>" class="form-control"  required>
		                                        </div>
		                                        <label class="control-label text-right col-md-1">To</label>
		                                        <div class="col-md-4">
		                                            <input type="text" id="to" name="to" value="<?php echo e(old('to')); ?>" class="form-control"  required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-5">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Assignment Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="project" value="<?php echo e(old('project')); ?>" class="form-control">
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                            <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Assignment Location</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="location" value="<?php echo e(old('location')); ?>" class="form-control" placeholder="Enter Location" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-5">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Client</label>
		                                        <div class="col-md-8">
		                                             <input type="text"  name="client" value="<?php echo e(old('client')); ?>" class="form-control" placeholder="Enter Client Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                            <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        
		                                        
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-5">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Country</label>
		                                        <div class="col-md-8">
		                                             <select  name="country"  class="form-control" required>
                                                        <option value=""></option>
                                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($country->name); ?>"><?php echo e($country->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                    </select>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
									 <div class="row">
		                                <!--/span-->
		                                <div class="col-md-12">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-2">Main Features</label>
		                                        <div class="col-md-9">
		                                         <textarea  rows=1 cols=5 id="main_features" name="main_features" class="form-control " ><?php echo e(old('main_features')); ?></textarea>
		                                        												
		                                        </div>  
		                                    </div>
		                                
		                                </div>
		                                <!--/span-->
		                            </div>

		                            <div class="row">
		                                <!--/span-->
		                                <div class="col-md-12">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-2">Activities</label>
		                                        <div class="col-md-9">
		                                         <textarea  rows=1 cols=5 id="activities" name="activities" class="form-control " ><?php echo e(old('activities')); ?></textarea>
		                                        
												 <input type="number" name="employee_id" value="<?php echo e(session('employee_id')); ?>"   class="form-control " hidden>
		                                        </div>  
		                                    </div>
		                                
		                                </div>
		                                <!--/span-->
		                            </div>
		                            <!--/row-->
		                                                    
		                           
		                        </div>
		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Add Experience</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>
		<?php if($experienceIds->count()!=0): ?>		                    
			                    <br>
			                    <hr>
			                    <br>
		<div class="card">
		<div class="card-body">
			<!--<div class="float-right">
				<input id="month" class="form-control" value="" type="month">
			</div>-->
			<h2 class="card-title">Stored Experience</h2>
			
			<div class="table-responsive m-t-40">
				
				<table id="myTable" class="table table-bordered table-striped" width="100%" cellspacing="0">
					<thead>
					
					<tr>
						<th>Employer Name</th>
						<th>Position</th>
						<th>From</th>
						<th>To</th>
						<?php if(Auth::user()->role_id==1): ?><th> Actions </th> <?php endif; ?>
					</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $experienceIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experienceId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($experienceId->employer); ?></td>
								<td><?php echo e($experienceId->position); ?></td>
								<td><?php echo e($experienceId->from); ?></td>
								<td><?php echo e($experienceId->to); ?></td>
								<td>
								<?php if(Auth::user()->role_id==1): ?>
								 <a class="btn btn-info btn-sm" href="<?php echo e(route('experience.edit',['id'=>$experienceId->id])); ?>" data-toggle="tooltip" data-original-title="Edit"> <i class="fas fa-pencil-alt text-white "></i></a>
								  <a class="btn btn-danger btn-sm" onclick="return confirm('Are you Sure to Delete')" href="<?php echo e(route('deleteExperience',['id'=>$experienceId->id])); ?>" data-toggle="tooltip" data-original-title="Delete"> <i class="fas fa-trash-alt"></i></a>
								 <?php endif; ?>
															
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					 
					
					</tbody>
				</table>
			</div>
		</div>
	</div>
	
	<?php endif; ?>
			                    
		        		</div>       
		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>

        <script>
            $(document).ready(function(){
				$( function() {
			    $( "#from, #to" ).datepicker({
			      dateFormat: 'yy-M-dd',
			      yearRange: '1960:'+ (new Date().getFullYear()),
			      changeMonth: true,
			      changeYear: true
			    });
		    	});

		    $('select').select2({
  			maximumSelectionLength: 2,

			});
			});

		</script>
		
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/hr/experience/experience.blade.php ENDPATH**/ ?>