<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Employee Name: <?php echo e($employee->first_name. " ".$employee->last_name); ?></h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   
    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-2">
					<?php echo $__env->make('layouts.master.hrVerticalEditButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
        			
		        	<div class="col-lg-10">

		                <div style="margin-top:10px; margin-right: 10px;">
		                    <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-info float-right">Back</button>
		                    
		                </div>
		                <div class="card-body">

		                    <form action="<?php echo route('editMembership', ['id'=>optional($data)->id]); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Membership</h3>
		                            <hr class="m-t-0 m-b-40">
		                            <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-2">Institute</label>
		                                        <div class="col-md-10">
		                                            <input type="text"  name="institute" value="<?php echo old('institute', optional($data)->institute); ?>" class="form-control" placeholder="Enter Institute Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-5">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-4">Membership No.</label>
		                                        <div class="col-md-8">
		                                            <input type="text" name="membership_no" value="<?php echo old('membership_no', optional($data)->membership_no); ?>" class="form-control " placeholder="Enter Countary Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                                
		                            <!--/row-->
		                             <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-2">Expiry Date</label>
		                                        <div class="col-md-5">
		                                            <input type="date"  name="expiry_date" value="<?php echo old('expiry_date', optional($data)->expiry_date); ?>" class="form-control"  required>
		                                        </div>
		                                       
		                                      
		                                    </div>
		                                </div>
		                                		                                
		                            </div>
		                            		                           
		                        </div>
		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Edit Membership</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>
		<?php if($membershipIds->count()!=0): ?>		                    
			                    <br>
			                    <hr>
			                    <br>
		<div class="card">
		<div class="card-body">
			<!--<div class="float-right">
				<input id="month" class="form-control" value="" type="month">
			</div>-->
			<h2 class="card-title">Stored Membership</h2>
			
			<div class="table-responsive m-t-40">
				
				<table id="myTable" class="table table-bordered table-striped" width="100%" cellspacing="0">
					<thead>
					
					<tr>
						<th>Institute</th>
						<th>Membership No.</th>
						<th>Expiry Date</th>
						
						<?php if(Auth::user()->role_id==1): ?><th> Actions </th> <?php endif; ?>
					</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $membershipIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membershipId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($membershipId->institute); ?></td>
								<td><?php echo e($membershipId->membership_no); ?></td>
								<td><?php echo e($membershipId->expiry_date); ?></td>
								
								<td>
								<?php if(Auth::user()->role_id==1): ?>
								 <a class="btn btn-info btn-sm" href="<?php echo e(route('membership.edit',['id'=>$membershipId->id])); ?>" data-toggle="tooltip" data-original-title="Edit"> <i class="fas fa-pencil-alt text-white "></i></a>
								 <?php endif; ?>
															
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					 
					
					</tbody>
				</table>
			</div>
		</div>
	</div>
	
	<?php endif; ?>
			                    
		        		</div>       
		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function(){
			
			});
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/membership/editMembership.blade.php ENDPATH**/ ?>