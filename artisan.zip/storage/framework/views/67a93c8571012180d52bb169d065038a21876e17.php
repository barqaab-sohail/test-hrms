<div class="btn-group-vertical" role="group" aria-label="vertical button group">

         <style>
            
        .btn-info:active { background-color: red; }
            
        </style>

          <br>

           <?php if(request()->is('*createProject')): ?>
             <a type="submit" role="button" href="<?php echo e(route('createProject')); ?>" class="btn btn-info <?php if(request()->is('*createProject')): ?> active <?php endif; ?>" >Project Information</a>

            <?php else: ?>
                 

           <a type="submit" role="button"  href="#" class="btn btn-info">Position & Reporting</a>
                     
           <a type="submit" role="button"   href="#" class="btn btn-info">Exit Interview</a>


             <?php endif; ?>
             
</div><?php /**PATH C:\xampp\htdocs\hrms\resources\views/layouts/master/projectVerticalButton.blade.php ENDPATH**/ ?>