<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Employee Name: <?php echo e($employee->first_name. " ".$employee->last_name); ?> </h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-2">
					<?php echo $__env->make('layouts.master.hrVerticalEditButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
        	
		        	<div class="col-lg-10">

		                <div style="margin-top:10px; margin-right: 10px;">
		                    <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-info float-right">Back</button>
		                </div>
		                <div class="card-body">

		                    <form id="employee" action="<?php echo e(route('editEmployee', ['id'=>$employee->id])); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Employee Information</h3>
		                            <hr class="m-t-0 m-b-40">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">First Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="first_name" value="<?php echo e(old('first_name', $employee->first_name)); ?>"   class="form-control" placeholder="Enter First Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Middle Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="middle_name" value="<?php echo e(old('middle_name', $employee->middle_name)); ?>" class="form-control " placeholder="Enter Middle Name" >
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Last Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="last_name" value="<?php echo e(old('last_name', $employee->last_name)); ?>"    class="form-control " placeholder="Enter Last Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Father Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="father_name" value="<?php echo e(old('father_name', $employee->father_name)); ?>" class="form-control " placeholder="Enter Father Name" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>
		                            <!--/row-->
		                            <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Date of Birth</label>
		                                        <div class="col-md-9">
		                                            <input type="text" id="date_of_birth" name="date_of_birth" value="<?php echo e(old('date_of_birth', $employee->date_of_birth)); ?>" class="form-control " placeholder="Enter Date of Birth" readonly required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Gender</label>
		                                        <div class="col-md-7">
		                                            
		                                           	 <select  name="gender"  class="form-control" required>
                                                         
		                                             	<option value="Male" <?php if($employee->gender == 'Male'): ?> selected="selected" <?php endif; ?>>Male</option>
                                                        <option value="Female" <?php if($employee->gender == 'Female'): ?> selected="selected" <?php endif; ?>>Female</option>
                                                                                                          
                                                    </select>
		                                        		                                        
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>
		                            <!--/row-->
		                            <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">CNIC</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="cnic" value="<?php echo e(old('cnic', $employee->cnic)); ?>" pattern="[0-9]{13}" title= "13 digit Number without dash" class="form-control " placeholder="Enter CNIC without dash" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">CNIC Expiry</label>
		                                        <div class="col-md-7">
		                                            
		                                            <input type="text" id="cnic_expiry" name="cnic_expiry" value="<?php echo e(old('cnic_expiry',$employee->cnic_expiry)); ?>" class="form-control " readonly required>
		                                       
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                
		                            </div>
		                            <!--/row-->

		                            
		                            <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Employee No.</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="employee_no" value="<?php echo e(old('employee_no',$employee->employee_no)); ?>" class="form-control " placeholder="Enter Employee No" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Marital Status</label>
		                                        <div class="col-md-7">
		                                           
		                                           	 <select  name="marital_status"  class="form-control" required>
                                                        
                                                        <?php $__currentLoopData = $maritalStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maritalStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														
														<option value="<?php echo e($maritalStatus->id); ?>" <?php if($maritalStatus->id == $employee->marital_status): ?> selected="selected" <?php endif; ?>><?php echo e($maritalStatus->name); ?></option>                                                        
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                    </select>
		                                        		                                        
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>
		                        <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Religon</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="religon" value="<?php echo e(old('religon',$employee->religon)); ?>" class="form-control " placeholder="Enter Religon" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Nationality</label>
		                                        <div class="col-md-7">
		                                          

		                                           	<select  name="nationality_name"  class="form-control" required>
		                                           	<option value=""></option>	
		                                           	<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                                           	<option value="<?php echo e($country->name); ?>" 
													<?php if($country->name ==  optional($nationality1)->nationality_name): ?>
		                                           	selected="selected" <?php endif; ?>><?php echo e($country->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    </select>
		                                            
		                                        </div>
		                                        <div class="col-md-2">
		                                       		<button type="button" name="add" id="add" class="btn btn-success">+</button>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>
								     <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                	<div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Division</label>
		                                        <div class="col-md-7">
		                                            
		                                           	 <select  name="division_id"  class="form-control" required>
                                                        <option value=""></option>
                                                        <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($division->id); ?>" <?php if($division->id == $employee->division_id): ?> selected="selected" <?php endif; ?>><?php echo e($division->name); ?></option>                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                               
                                                    </select>
		                                            
		                                       
		                                        </div>
		                                    </div>
		                                    
		                                </div>
		                               
		                               <div id="nationality2" class="col-md-6">
		                                   
											<div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Nationality-2</label>
		                                        <div class="col-md-7">
		                                          	<select  name="nationality_name2"  class="form-control" >
		                                           	<option value=""></option>
		                                           	<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($country->name); ?>" <?php if($country->name == optional($nationality2)->nationality_name): ?> selected="selected" <?php endif; ?>><?php echo e($country->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 	
                                                    </select>
		                                        </div>
		                                    </div>
		                                </div>
		                               
		                                <!--/span-->
		                            </div>


		                        </div>
		                        <?php if(Auth::user()->role_id==1): ?>
		                        <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Edit Employee</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                        <?php endif; ?>
		                    </form>
		        		</div>       
		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>
    <script>
    $(document).ready(function(){
    	
        $( function() {
		    $( "#date_of_birth" ).datepicker({
		      dateFormat: 'dd-MM-yy',
		      yearRange: '1940:'+ (new Date().getFullYear()-15),
		      changeMonth: true,
		      changeYear: true
		    });
		    $( "#cnic_expiry" ).datepicker({
		      dateFormat: 'dd-MM-yy',
		      yearRange:  new Date().getFullYear()+':'+(new Date().getFullYear()+15),
		      changeMonth: true,
		      changeYear: true
		    });
		    		    
  		});

        $('select').select2({
  			maximumSelectionLength: 2,

		});

        $("#nationality2").hide();
		$("#add").click (function(){
		  		$("#nationality2").toggle();
	  	});
	});
    </script>

        

    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/hr/employee/editEmployee.blade.php ENDPATH**/ ?>