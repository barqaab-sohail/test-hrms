<div class="btn-group-vertical" role="group" aria-label="vertical button group">

         <style>
            
        .btn-info:active { background-color: red; }
            
        </style>

          <br>

           <?php if(request()->is('*/edit/*') || request()->is('education')|| request()->is('salary')): ?>
            <a type="submit" role="button" href="<?php echo e(route('createEmployee')); ?>" class="btn btn-info <?php if(request()->is('createEmployee')|| request()->is('employee/edit*')): ?> active <?php endif; ?>" >Personal Information</a>
            <a type="submit" role="button"  href="<?php echo e(route('education')); ?>" class="btn btn-info <?php if(request()->is('education/*')): ?> active <?php endif; ?>">Education</a>
            <a type="submit" role="button" href="#" class="btn btn-info <?php if(request()->is('salary')): ?> active <?php endif; ?>">Salary</a>
            <a type="submit" role="button"  href="#" class="btn btn-info">Position & Reporting</a>
            <a type="submit" role="button"  href="#" class="btn btn-info ">Contact Detail</a>
            <a type="submit" role="button"  href="#" class="btn btn-info">Emergency Contact</a>
            <a type="submit" role="button"  href="#"  class="btn btn-info">Experience</a>
            <a type="submit" role="button"  href="#" class="btn btn-info">Training</a>
            <a type="submit" role="button"  href="#" class="btn btn-info">Dependent</a>
            <a type="submit" role="button"  href="#" class="btn btn-info">Documents</a>
            <a type="submit" role="button"   href="#" class="btn btn-info">Exit Interview</a>
             
             <?php else: ?>
              <a type="submit" role="button" href="<?php echo e(route('createEmployee')); ?>" class="btn btn-info <?php if(request()->is('createEmployee')): ?> active <?php endif; ?>" >Personal Information</a>
             <?php endif; ?>
             
</div><?php /**PATH C:\xampp\htdocs\hrms\resources\views/layouts/master/hrVerticalButton.blade.php ENDPATH**/ ?>