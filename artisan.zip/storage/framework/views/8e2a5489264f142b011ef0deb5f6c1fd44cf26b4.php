<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Project Detail</h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-2">
					<?php echo $__env->make('layouts.master.projectVerticalButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
        	
		        	<div class="col-lg-10">

		                <div style="margin-top:10px; margin-right: 10px;">
		                    <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-info float-right">Back</button>
		                </div>
		                <div class="card-body">

		                    <form action="<?php echo e(route('storeProject')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Project Information</h3>
		                            <hr class="m-t-0 m-b-40">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Project Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="name" value="<?php echo e(old('name')); ?>"  class="form-control" placeholder="Enter Name of Project" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Client Name</label>
		                                        <div class="col-md-9">
		                                            <input type="text" name="client" value="<?php echo e(old('client')); ?>" class="form-control " placeholder="Enter Client Name" >
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Start Date</label>
		                                        <div class="col-md-6">
		                                            <input type="date" name="commencement" value="<?php echo e(old('commencement')); ?>"   class="form-control " placeholder="Enter Commencement Date" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Contractual Completion</label>
		                                        <div class="col-md-6">
		                                            <input type="date" name="contractual_completion" value="<?php echo e(old('contractual_completion')); ?>" class="form-control " placeholder="Enter Contractual Completion Date" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>
		                            <!--/row-->
		                            <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Actual Completion</label>
		                                        <div class="col-md-6">
		                                            <input type="date" name="actual_completion" value="<?php echo e(old('actual_completion')); ?>" class="form-control " placeholder="Enter Actual Completion Date" >
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Type</label>
		                                        <div class="col-md-6">
		                                  		<select  name="type"  class="form-control" required>
                                                    <option value=""></option>
                                                    <option value="Lumpsum">Lumpsum</option>
                                                    <option value="Time Based">Time Based</option>
                                                </select>
		                                        		                                        
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>

		                            <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Status</label>
		                                        <div class="col-md-6">
		                                        <select  name="status"  class="form-control" required>
                                                        <option value=""></option>
                                                        <option value="In Progress">In Progress</option>
                                                        <option value="Completed">Completed</option>
                                                        <option value="Suspended">Suspended</option>
                                                    </select>
                                                </div>
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Role</label>
		                                        <div class="col-md-6">
		                                            
		                                           	 <select  name="role"  class="form-control" required>
                                                        <option value=""></option>
                                                        <option value="Independent">Independent</option>
                                                        <option value="Lead Partner">Lead Partner</option>
                                                        <option value="JV Partner">JV Partner</option>
                                                        <option value="Sub Consultant">Sub Consultant</option>
                                                    </select>
		                                        		                                        
		                                        </div>
		                                    </div>
		                                </div>
		                                <!--/span-->
		                            </div>

		                            <div class="row">
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Percentage Share</label>
		                                        <div class="col-md-6">

		                                        <input type="text"  name="share" value="<?php echo e(old('share')); ?>"  class="form-control" placeholder="Enter %age Share" required>
		                                        
                                                </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                            </div>
		                            

		                        </div>
		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Add Project</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>
		        		</div>       
		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>
        <script>

        </script>

        

    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/project/createProject.blade.php ENDPATH**/ ?>