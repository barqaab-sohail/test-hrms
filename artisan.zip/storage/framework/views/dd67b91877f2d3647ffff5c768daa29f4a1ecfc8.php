<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Employee Name: <?php echo e($employee->first_name. " ".$employee->last_name); ?></h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   

    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-2">
					<?php echo $__env->make('layouts.master.hrVerticalEditButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
        			
		        	<div class="col-lg-10">
						
		                <div style="margin-top:10px; margin-right: 10px;">
		                    <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-info float-right">Back</button>
		                    
		                </div>
		                <div class="card-body">

		                    <form action="<?php echo e(route('editOther', ['id'=>$employee->id])); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Other Information</h3>
		                            <hr class="m-t-0 m-b-40">
		                            <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Driving Licence</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="driving_licence" value="<?php echo old('driving_licence',isset($employee->other_information->driving_licence)?$employee->other_information->driving_licence:''); ?>" class="form-control" placeholder="Enter Driving Licence No." required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-5">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Expiry Date</label>
		                                        <div class="col-md-7">
		                                            <input type="date"  name="licence_expiry" value="<?php echo old('licence_expiry',isset($employee->other_information->licence_expiry)?$employee->other_information->licence_expiry:''); ?>" class="form-control" placeholder="Enter Driving Licence Expiry" required>
		                                        </div>
		                                    </div>
		                                    
		                                    </div>
		                                </div>
		                            </div>

		                            <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Disability</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="disability" value="<?php echo old('disability',isset($employee->other_information->disability)?$employee->other_information->disability:''); ?>" class="form-control" placeholder="Enter Disability Detail" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-5">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Blood Group</label>
		                                        <div class="col-md-7">
		                                            <select  name="blood_group"  class="form-control" required>
                                                        <option value=""></option>
                                                        <?php $__currentLoopData = $blood_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<option value="<?php echo e($blood_group->id); ?>"
															<?php if(!empty($employee->other_information->blood_group)): ?>
																<?php if($blood_group->id == $employee->other_information->blood_group): ?> selected="selected" <?php endif; ?>
															<?php endif; ?>
															><?php echo e($blood_group->name); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                               
                                                    </select>

		                                        </div>
		                                    </div>
		                                    
		                                </div>
		                            </div>

		                            <div class="row">
		                                <div class="col-md-7">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Passport No</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="passport_no" value="<?php echo old('passport_no',isset($employee->other_information->passport_no)?$employee->other_information->passport_no:''); ?>" class="form-control" placeholder="Enter Passport No." required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-5">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Expiry Date</label>
		                                        <div class="col-md-7">
		                                            <input type="date"  name="passport_expiry" value="<?php echo old('passport_expiry',isset($employee->other_information->passport_expiry)?$employee->other_information->passport_expiry:''); ?>" class="form-control" placeholder="Enter Passport Expiry" required>
		                                        </div>
		                                    </div>
		                                    <input type="text"  name="employee_id" value="<?php echo e(session('employee_id')); ?>

		                                            " class="form-control" hidden >
		                                    </div>
		                                </div>
		                            </div>

		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Save</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>
		        		</div>       
		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>
        <script>
            
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/other_information/editOther.blade.php ENDPATH**/ ?>