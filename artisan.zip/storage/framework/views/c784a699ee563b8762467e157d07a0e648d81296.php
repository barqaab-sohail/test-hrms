<?php $__env->startSection('Heading'); ?>
	<h3 class="text-themecolor">Employee Name: <?php echo e($employee->first_name. " ".$employee->last_name); ?></h3>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="javascript:void(0)"></a></li>
		
		
	</ol>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   

    <div class="row">
        <div class="col-lg-12">

            <div class="card card-outline-info">
			
				<div class="row">
					<div class="col-lg-2">
					<?php echo $__env->make('layouts.master.hrVerticalEditButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
        			
		        	<div class="col-lg-10">
						
		                <div style="margin-top:10px; margin-right: 10px;">
		                    <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-info float-right">Back</button>
		                    
		                </div>
		                <div class="card-body">

		                    <form action="<?php echo e(route('editPermanentAddress', ['id'=>$employee->id])); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Permanent Address</h3>
		                            <hr class="m-t-0 m-b-40">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">House No.</label>
		                                        <div class="col-md-9 text-required">
		                                            <input type="text"  name="house" value="<?php echo old('house',isset($permanentAddress->house)?$permanentAddress->house:''); ?>" class="form-control" placeholder="Enter House Name / No." required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Street No.</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="street" value="<?php echo old('street',isset($permanentAddress->street)?$permanentAddress->street:''); ?>" class="form-control" placeholder="Enter Street Name / No." >
		                                        </div>
		                                    </div>
		                                    
		                                </div>
		                            </div>
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Town / Village</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="town" value="<?php echo old('house',isset($permanentAddress->town)?$permanentAddress->town:''); ?>" class="form-control" placeholder="Enter Town / Village" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Tehsil</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="tehsil" value="<?php echo old('tehsil',isset($permanentAddress->tehsil)?$permanentAddress->tehsil:''); ?>" class="form-control" placeholder="Enter Tehsil Name " >
		                                        </div>
		                                    </div>
		                                    
		                                </div>
		                            </div>
		                             <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">City / District</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="city" value="<?php echo old('city',isset($permanentAddress->city)?$permanentAddress->city:''); ?>" class="form-control" placeholder="Enter City / District Name " required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                       <label class="control-label text-right col-md-3">Province</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="province" value="<?php echo old('house',isset($permanentAddress->province)?$permanentAddress->province:''); ?>" class="form-control" placeholder="Enter Province" required>
		                                        </div>

		                                    </div>
		                                    
		                                </div>
		                            </div>
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Country</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="country" value="<?php echo old('country',isset($permanentAddress->country)?$permanentAddress->country:''); ?>" class="form-control" placeholder="Enter Country Name " required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        
		                                    </div>
		                                    
		                                </div>
		                            </div>
		                             <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Mobile No.</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="mobile" value="<?php echo old('house',isset($permanentAddress->mobile)?$permanentAddress->mobile:''); ?>" class="form-control" placeholder="Enter Mobile No" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Landline No.</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="landline" value="<?php echo old('landline',isset($permanentAddress->landline)?$permanentAddress->landline:''); ?>" class="form-control" placeholder="Enter Landline No. " >
		                                        </div>
												<input type="number" name="employee_id" value="<?php echo e(session('employee_id')); ?>"   class="form-control " hidden>
												
												<input type="number" name="type" value="<?php echo e(0); ?>"   class="form-control " hidden>

		                                    </div>
		                                    
		                                </div>
		                            </div>


		                        </div>
		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Save Permanent Address</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>
		        		</div>       
						
						<hr>

						 <div class="card-body">

		                    <form action="<?php echo e(route('editCurrentAddress', ['id'=>$employee->id])); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
		                        <?php echo e(csrf_field()); ?>

		                        <div class="form-body">
		                            
		                            <h3 class="box-title">Current Address</h3>
		                            <hr class="m-t-0 m-b-40">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">House No.</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="house" value="<?php echo old('house',isset($currentAddress->house)?$currentAddress->house:''); ?>" class="form-control" placeholder="Enter House Name / No." >
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Street No.</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="street" value="<?php echo old('street',isset($currentAddress->street)?$currentAddress->street:''); ?>" class="form-control" placeholder="Enter Street Name / No." >
		                                        </div>
		                                    </div>
		                                    
		                                </div>
		                            </div>
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Town / Village</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="town" value="<?php echo old('house',isset($currentAddress->town)?$currentAddress->town:''); ?>" class="form-control" placeholder="Enter Town / Village" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Tehsil</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="tehsil" value="<?php echo old('tehsil',isset($currentAddress->tehsil)?$currentAddress->tehsil:''); ?>" class="form-control" placeholder="Enter Tehsil Name " >
		                                        </div>
		                                    </div>
		                                    
		                                </div>
		                            </div>
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">City / District</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="city" value="<?php echo old('city',isset($currentAddress->city)?$currentAddress->city:''); ?>" class="form-control" placeholder="Enter City / District Name " required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Province</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="province" value="<?php echo old('house',isset($currentAddress->province)?$currentAddress->province:''); ?>" class="form-control" placeholder="Enter Province" required>
		                                        </div>
		                                    </div>
		                                    
		                                </div>
		                            </div>
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Country</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="country" value="<?php echo old('country',isset($currentAddress->country)?$currentAddress->country:''); ?>" class="form-control" placeholder="Enter Country Name " required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        
		                                    </div>
		                                    
		                                </div>
		                            </div>
		                             <div class="row">
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Mobile No.</label>
		                                        <div class="col-md-9">
		                                            <input type="text"  name="mobile" value="<?php echo old('house',isset($currentAddress->mobile)?$currentAddress->mobile:''); ?>" class="form-control" placeholder="Enter Mobile No" required>
		                                        </div>
		                                    </div>
		                                </div>
		                                
		                                <!--/span-->
		                                <div class="col-md-6">
		                                    <div class="form-group row">
		                                        <label class="control-label text-right col-md-3">Landline No.</label>
		                                        <div class="col-md-9">

		                                            <input type="text"  name="landline" value="<?php echo old('landline',isset($currentAddress->landline)?$currentAddress->landline:''); ?>" class="form-control" placeholder="Enter Landline No. " >
		                                        </div>
												<input type="number" name="employee_id" value="<?php echo e(session('employee_id')); ?>"   class="form-control " hidden>
												
												<input type="number" name="type" value="<?php echo e(1); ?>"   class="form-control " hidden>


		                                    </div>
		                                    
		                                </div>
		                            </div>

		                        </div>
		                         <hr>
		                        <div class="form-actions">
		                            <div class="row">
		                                <div class="col-md-6">
		                                    <div class="row">
		                                        <div class="col-md-offset-3 col-md-9">
		                                            <button type="submit" class="btn btn-success">Save Current Address</button>
		                                            <button type="button" onclick="window.location.href='<?php echo e(route('employeeList')); ?>'" class="btn btn-inverse">Cancel</button>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                    </form>
		        		</div>       


		        	</div>
		        </div>
            </div>
        </div>
    </div>
 <?php $__env->startPush('scripts'); ?>
        <script>
           
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\resources\views/hr/contact/editContact.blade.php ENDPATH**/ ?>